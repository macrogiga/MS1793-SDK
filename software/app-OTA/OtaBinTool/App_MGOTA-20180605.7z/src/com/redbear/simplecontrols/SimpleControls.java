package com.redbear.simplecontrols;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;

public class SimpleControls extends Activity {
	private final static String TAG = SimpleControls.class.getSimpleName();

	private Button connectBtn = null;
	private TextView rssiValue = null;
	private TextView RssiText = null;
	private TextView AnalogInValue = null;
	private ToggleButton /*digitalOutBtn, digitalInBtn,*/ AnalogInBtn;
	//private SeekBar servoSeekBar, PWMSeekBar;

	private BluetoothGattCharacteristic characteristicTx = null;
	private RBLService mBluetoothLeService;
	private BluetoothAdapter mBluetoothAdapter;
	private BluetoothDevice mDevice = null;
	private String mDeviceAddress;

	//private byte[] mDeviceName = new byte[30];
	private String mAdvName=null;
	private static int CharWriteSuccFlag = 0; // 0pending, 1 succ, 2 fail
	//OTA
	//private int OTA_PackageID = 0;//A or B
	private int OTA_PackageLen = 0;

	private boolean flag = true;
	private boolean connState = false;
	private boolean scanFlag = false;

	private byte[] data = new byte[3];
	private static final int REQUEST_ENABLE_BT = 1;
	private static final int REQUEST_SELECT_DEVICE = 2;
	private static final long SCAN_PERIOD = 5000;

	final private static char[] hexArray = { '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    private String OTaPercent = "";

    private Button bFileSel;
    private String rootPath="/";
    //private TextView mPath;
    File myFile;

	private TextView tvFileName;
	private TextView tvFileSize;
	private ProgressBar pbOTA;

	private final ServiceConnection mServiceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName componentName,
				IBinder service) {
			mBluetoothLeService = ((RBLService.LocalBinder) service)
					.getService();
			if (!mBluetoothLeService.initialize()) {
				Log.e(TAG, "Unable to initialize Bluetooth");
				finish();
			}
		}

		@Override
		public void onServiceDisconnected(ComponentName componentName) {
			mBluetoothLeService = null;
		}
	};

	private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			final String action = intent.getAction();

			if (RBLService.ACTION_GATT_DISCONNECTED.equals(action)) {
				Toast.makeText(getApplicationContext(), "Disconnected",
						Toast.LENGTH_SHORT).show();
				setButtonDisable();
				scanFlag = false;
				connState = false;
				RssiText.setText("disconected");
			} else if (RBLService.ACTION_GATT_SERVICES_DISCOVERED
					.equals(action)) {
				//scanFlag = true;
				Toast.makeText(getApplicationContext(), "Connected",
						Toast.LENGTH_SHORT).show();
				setButtonEnable();

				getGattService(mBluetoothLeService.getSupportedGattService());
			} else if (RBLService.ACTION_DATA_AVAILABLE.equals(action)) {
				data = intent.getByteArrayExtra(RBLService.EXTRA_DATA);

				readAnalogInValue(data);
			} else if (RBLService.ACTION_GATT_RSSI.equals(action)) {
				displayData(intent.getStringExtra(RBLService.EXTRA_DATA));
			} else if (RBLService.ACTION_GATT_CHAR_WRITE_SUCCESS.equals(action)) {
				CharWriteSuccFlag = 1;
			}else if (RBLService.ACTION_GATT_CHAR_WRITE_FAIL.equals(action)) {
				CharWriteSuccFlag = 2;
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.main);
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.title);

		rssiValue = (TextView) findViewById(R.id.rssiValue);
		RssiText = (TextView) findViewById(R.id.Rssi); //display adv name

		AnalogInValue = (TextView) findViewById(R.id.AIText);

		//digitalInBtn = (ToggleButton) findViewById(R.id.DIntBtn);

        //mPath = (TextView) findViewById(R.id.txt2);
		tvFileName = (TextView)findViewById(R.id.digitalIn);
		tvFileSize = (TextView)findViewById(R.id.PWM);
		pbOTA = (ProgressBar)findViewById(R.id.progressBar);
		pbOTA.setVisibility(View.GONE);
		pbOTA.setProgress(0);


        bFileSel = (Button) findViewById(R.id.button) ;
        bFileSel.setOnClickListener(new Button.OnClickListener(){

            @Override
            public void onClick(View v){
                String sDStateString = android.os.Environment.getExternalStorageState();
                if(sDStateString.equals(Environment.MEDIA_MOUNTED)){
                    try{
                        File SDFile = android.os.Environment.getExternalStorageDirectory();
                        myFile = new File(SDFile.getAbsolutePath()+File.separator+"mgbin.ota");

                        if(!myFile.exists()){
                            //mPath.setText("put OTA file to SDCARD root!");
                            Toast toast = Toast.makeText(SimpleControls.this, "NO OTA Files! Put mgbin.ota to /SDCARD/", Toast.LENGTH_SHORT);
                            toast.setGravity(0,0,Gravity.CENTER);
                            toast.show();

							tvFileName.setText("OTA file Not Exists. Put mgbin.ota to /SDCARD");
							tvFileSize.setText("FileSize:");
                            //mPath.setText(SDFile.getAbsolutePath()+File.separator+"bin Not Exists");

                            //myFile.createNewFile();
                            //String szOutText = "MG OTA Header";
                            //FileOutputStream outputStream = new FileOutputStream(myFile);
                            //outputStream.write(szOutText.getBytes());
                            //outputStream.flush();
                            //outputStream.close();
                        }else{
                            //mPath.setText(myFile.getName());
                            Toast toast = Toast.makeText(SimpleControls.this, "FileName: "+myFile.getName()+"\r\nFileLen: "+myFile.length()+" Byte", Toast.LENGTH_LONG);
                            toast.setGravity(0,0,Gravity.CENTER);
                            toast.show();
							tvFileName.setText("FileName: "+myFile.getName());
							tvFileSize.setText("FileSize: "+myFile.length()+" Bytes");
                        }
                    } catch (Exception e) {

                    }

                }else if(sDStateString.endsWith(Environment.MEDIA_MOUNTED_READ_ONLY)){
                    //mPath.setText("READ ONLY!");

                }
            }
        });

		connectBtn = (Button) findViewById(R.id.connect);
		connectBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				if (connState == false) {

					//connState = false;

					Intent newIntent = new Intent(SimpleControls.this, DeviceListActivity.class);
					startActivityForResult(newIntent, REQUEST_SELECT_DEVICE);

				}else {

                    {
                        mBluetoothLeService.disconnect();
                        mBluetoothLeService.close();
                        setButtonDisable();
                        scanFlag = false;
                    }
                }
			}
		});
/*
		digitalOutBtn = (ToggleButton) findViewById(R.id.DOutBtn);
		digitalOutBtn.setHeight(1);
		digitalOutBtn.setOnCheckedChangeListener(new OnCheckedChangeListener() {
		digitalInBtn.setOnCheckedChangeListener(new OnCheckedChangeListener() {  //OTA B

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				/*byte buf[] = new byte[] { (byte) 0x01, (byte) 0x00, (byte) 0x00 };

				if (isChecked == true)
					buf[1] = 0x01;
				else
					buf[1] = 0x00;

				characteristicTx.setValue(buf);
				mBluetoothLeService.writeCharacteristic(characteristicTx);/
				OTA_PackageID = 1;//OTA B
				startOtaProc();
			}
		});*/

		AnalogInBtn = (ToggleButton) findViewById(R.id.AnalogInBtn);  //OTA switch A
		AnalogInBtn.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {

				if(isChecked == true){
					startOtaProc();
				}else{


				}

			}
		});


		if (!getPackageManager().hasSystemFeature(
				PackageManager.FEATURE_BLUETOOTH_LE)) {
			Toast.makeText(this, "Ble not supported", Toast.LENGTH_SHORT)
					.show();
			finish();
		}

		final BluetoothManager mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
		mBluetoothAdapter = mBluetoothManager.getAdapter();
		if (mBluetoothAdapter == null) {
			Toast.makeText(this, "Ble not supported", Toast.LENGTH_SHORT)
					.show();
			finish();
			return;
		}

		Intent gattServiceIntent = new Intent(SimpleControls.this,
				RBLService.class);
		bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
	}

	@Override
	protected void onResume() {
		super.onResume();

		if (!mBluetoothAdapter.isEnabled()) {
			Intent enableBtIntent = new Intent(
					BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
		}

		registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
	}

	private void displayData(String data) {
		String ota_len = "";
		if(OTA_PackageLen != 0)ota_len = String.valueOf(OTA_PackageLen);
		if (data != null) {
//			rssiValue.setText(bytesToHex(mDeviceName)+":"+data+"=>>"+OTaPercent);
			rssiValue.setText("rssi="+data+"=>>"+OTaPercent);
			if(null!=mAdvName)RssiText.setText(ota_len+" "+mAdvName);
			else
			{
				//RssiText.setText("***");
				//RssiText.setText(mDevice.getAddress()+":"+ota_len);
				if(mDevice != null)RssiText.setText(ota_len+" "+mDevice.getName());
				else RssiText.setText(ota_len+"***");
			}
		}
	}

	private void readAnalogInValue(byte[] data) {
		for (int i = 0; i < data.length; i += 3) {
			if (data[i] == 0x0A) {
				//if (data[i + 1] == 0x01)
					//digitalInBtn.setChecked(false);
				//else
					//digitalInBtn.setChecked(true);
			} else if (data[i] == 0x0B) {
				int Value;

				Value = ((data[i + 1] << 8) & 0x0000ff00)
						| (data[i + 2] & 0x000000ff);

				AnalogInValue.setText(Value + "");
			}
		}
	}

	private void setButtonEnable() {
		flag = true;
		connState = true;

		AnalogInBtn.setEnabled(true);
		pbOTA.setVisibility(View.VISIBLE);
		pbOTA.setEnabled(true);
		connectBtn.setText("Disconnect");
	}

	private void setButtonDisable() {
		flag = false;
		connState = false;

		AnalogInBtn.setEnabled(false);
		AnalogInBtn.setChecked(false);
		pbOTA.setEnabled(false);
		connectBtn.setText("Connect");
	}

	private void startReadRssi() {
		new Thread() {
			public void run() {

				while (flag) {
					mBluetoothLeService.readRssi();
					try {
						sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			};
		}.start();
	}

	private void PackingMgOtaFrameBuf(byte[] OTA_File,int ota_file_pos,int maxlen,byte[]OneBleOtaBuf)
	{
		int sn = ota_file_pos / 16;
		int checksum = 0;
		int i,t;
		int len = 16;

		if(maxlen - ota_file_pos < 16)
		{
			len = maxlen - ota_file_pos;
		}

		OneBleOtaBuf[0] = (byte)(sn&0xff);
		OneBleOtaBuf[1] = (byte)((sn>>8)&0xff);
		OneBleOtaBuf[2] = (byte)(0xff);

		for(i = 0 ; i < len ; i ++)
		{
			t = OTA_File[i + ota_file_pos];
			OneBleOtaBuf[i+4] = OTA_File[i + ota_file_pos];

			checksum = checksum + (t & 0xFF);
		}

		if(len < 16)//fill zero
		{
			for(i = len ; i < 16 ; i ++) {
				OneBleOtaBuf[i + 4] = (byte)0;
			}
		}

		checksum = checksum + 0xff;
		checksum = checksum + (sn&0xFF);
		checksum = checksum + ((sn>>8)&0xFF);

		checksum = checksum & 0xFF;

		OneBleOtaBuf[3] = (byte)(0xff-checksum);
	}

    private void startOtaProc() {
        new Thread() {
            public void run() {
                int i = 0;
				int ota_file_pos = 0;
				byte OneBleOtaBuf[] = new byte[20];
				byte[]  OTA_File = null;

				CharWriteSuccFlag = 0xff;//OK,start

                if(!myFile.exists()){
                    //mPath.setText("No OTA file! Check OTA file first!");
                }else{
                    try{
                        FileInputStream inputStream =  new FileInputStream(myFile);
                        OTA_PackageLen = inputStream.available();
                        if(OTA_PackageLen != 0){
                            OTA_File = new byte[OTA_PackageLen];
                            inputStream.read(OTA_File);
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }


				while (flag && (0 != OTA_PackageLen)) {
					if(CharWriteSuccFlag == 0xff) { //start
						ota_file_pos = 0;
						CharWriteSuccFlag = 1;
					}
					else if(CharWriteSuccFlag == 1) { //succ
						ota_file_pos += 16;
					}
					else if(CharWriteSuccFlag == 2)  //retransmit
					{
						CharWriteSuccFlag = 1;
					}

					if(ota_file_pos >= OTA_PackageLen){
						pbOTA.setProgress(100);
						break;//end
					}

					if(CharWriteSuccFlag == 1)
					{
						OTaPercent =  String.valueOf(ota_file_pos);//show percentage

						pbOTA.setProgress((int)(ota_file_pos*100/OTA_PackageLen));

						/*package one buf*/
						//tbd...
						PackingMgOtaFrameBuf(OTA_File,ota_file_pos,OTA_PackageLen,OneBleOtaBuf);

						//OneBleOtaBuf[1] = (byte)(ota_file_pos & 0xff);
						//OneBleOtaBuf[0] = (byte)((ota_file_pos>>8) & 0xff);

						characteristicTx.setValue(OneBleOtaBuf);
						mBluetoothLeService.writeCharacteristic(characteristicTx);

						CharWriteSuccFlag = 0; //pending
					}

                    try {
                        sleep(5);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            };
        }.start();

		OTA_PackageLen = 0;

    }

	private void getGattService(BluetoothGattService gattService) {
		if (gattService == null)
			return;

		characteristicTx = gattService
				.getCharacteristic(RBLService.UUID_BLE_SHIELD_TX);

		if(characteristicTx != null) {
			setButtonEnable();
			startReadRssi();
		}

/*
		BluetoothGattCharacteristic characteristicRx = gattService
				.getCharacteristic(RBLService.UUID_BLE_SHIELD_RX);
		mBluetoothLeService.setCharacteristicNotification(characteristicRx,
				true);
		mBluetoothLeService.readCharacteristic(characteristicRx);*/
	}

	private static IntentFilter makeGattUpdateIntentFilter() {
		final IntentFilter intentFilter = new IntentFilter();

		intentFilter.addAction(RBLService.ACTION_GATT_CONNECTED);
		intentFilter.addAction(RBLService.ACTION_GATT_DISCONNECTED);
		intentFilter.addAction(RBLService.ACTION_GATT_SERVICES_DISCOVERED);
		intentFilter.addAction(RBLService.ACTION_DATA_AVAILABLE);
		intentFilter.addAction(RBLService.ACTION_GATT_RSSI);

		intentFilter.addAction(RBLService.ACTION_GATT_CHAR_WRITE_SUCCESS);
		intentFilter.addAction(RBLService.ACTION_GATT_CHAR_WRITE_FAIL);

		return intentFilter;
	}



	private int ParserScanData(final byte[] scanRecord, byte[] ServiceUUID16/*, byte[] sName*/)
	{
		//2,1,6, 3,3,0x90,0xfe,3,9,'a','c',0x09 ,0xFF ,0x11 ,0x02 ,0x11 ,0x02 ,0x93 ,0xF5 ,0x40 ,0xE1};//mesh lamp
		int i,j;
		int rec_len;
		char [] Name = new char[30];

		mAdvName = null;

		rec_len = scanRecord.length;

		//find service UUID16
		ServiceUUID16[0] = 0;
		ServiceUUID16[1] = 0;

		for(i = 0 ; i < /*rec_len*/31 ; i ++)
		{
			if(scanRecord[i+1] == 0x03)//found
			{
				ServiceUUID16[0] = scanRecord[i+2];
				ServiceUUID16[1] = scanRecord[i+3];
				break;
			}
			else
			{
				i = i + scanRecord[i];
			}
			if(scanRecord[i]==0)break;
		}

		//find Name if any
//		Name[0] = 0x20;
//		Name[1] = 0;
//		for(i = 0 ; i < rec_len/*31*/ ; i ++)
//		{
//			if((scanRecord[i+1] == 0x08) || (scanRecord[i+1] == 0x09))//found
//			{
//				for(j = 0 ; j < scanRecord[i]-1; j ++) {
//					Name[j] = (char)scanRecord[i+2+j];
//				}
//				Name[j] = 0;

//				mAdvName = new String(Name);
//				break;
//			}
//			else
//			{
//				i = i + scanRecord[i];
//			}
//			if(scanRecord[i]==0)break;
//		}

		return 1;
	}

	private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

		@Override
		public void onLeScan(final BluetoothDevice device, final int rssi,
				final byte[] scanRecord) {

			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					byte[] serviceUuidBytes = new byte[2];
					/*String serviceUuid = "";
					for (int i = 0, j = 0; i <= 10; i++, j++) {
						serviceUuidBytes[j] = scanRecord[i];
					}
					if (stringToUuidString(serviceUuid).equals(
							RBLGattAttributes.BLE_SHIELD_SERVICE
									.toUpperCase(Locale.ENGLISH))) */
					if(mDevice == null) {
						ParserScanData(scanRecord,serviceUuidBytes/*,mDeviceName*/);

						if (null != mAdvName) RssiText.setText("[scan]:" + mAdvName);
						else RssiText.setText(" -**- ");

						if (serviceUuidBytes[0] != 0x00)
							rssiValue.setText(bytesToHex(serviceUuidBytes));
						else rssiValue.setText("0000");
					}
					//if((scanRecord[0] == 0x02) && (scanRecord[2] == 0x06) && (scanRecord[3] == 0x0b) && (scanRecord[4] == 0x08) && (scanRecord[5] == 0x6d))
					//if((serviceUuidBytes[0] == 0x12) && (serviceUuidBytes[1] == 0x18))
					//if((((char)serviceUuidBytes[0] & 0xFF) == 0x12) && (((char)serviceUuidBytes[1] & 0xFF) == 0x18))//hid uuid
					if((((char)serviceUuidBytes[0] & 0xFF) == 0x90) && (((char)serviceUuidBytes[1] & 0xFF) == 0xfe) && (rssi > -60))//BLE LED uuid
					{
						if(mDevice == null) {
							if(null!=mAdvName)RssiText.setText("found:"+/*mAdvName*/device.getName());
							else RssiText.setText(" -**- ");

							//RssiText.setText("connecting..."+/*mAdvName*/device.getName());
							//RssiText.setText("connecting..."+/*mAdvName*/device.getAddress());
							RssiText.setText(device.getName()+"(To)");
							mDevice = device;
						}
						else
						{
							//RssiText.setText("connecting...");
						}
					}
				}
			});
		}
	};

	private String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];
		int v;
		for (int j = 0; j < bytes.length; j++) {
			v = bytes[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}

	private String stringToUuidString(String uuid) {
		StringBuffer newString = new StringBuffer();
		newString.append(uuid.toUpperCase(Locale.ENGLISH).substring(0, 8));
		newString.append("-");
		newString.append(uuid.toUpperCase(Locale.ENGLISH).substring(8, 12));
		newString.append("-");
		newString.append(uuid.toUpperCase(Locale.ENGLISH).substring(12, 16));
		newString.append("-");
		newString.append(uuid.toUpperCase(Locale.ENGLISH).substring(16, 20));
		newString.append("-");
		newString.append(uuid.toUpperCase(Locale.ENGLISH).substring(20, 32));

		return newString.toString();
	}

	@Override
	protected void onStop() {
		super.onStop();

		flag = false;

		unregisterReceiver(mGattUpdateReceiver);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		if (mServiceConnection != null)
			unbindService(mServiceConnection);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// User chose not to enable Bluetooth.
		if (requestCode == REQUEST_ENABLE_BT
				&& resultCode == Activity.RESULT_CANCELED) {
			finish();
			return;
		}

        if((requestCode == REQUEST_SELECT_DEVICE)
            &&(resultCode == Activity.RESULT_OK)&&(data != null)){
            String deviceAddress = data.getStringExtra(BluetoothDevice.EXTRA_DEVICE);
            mDevice = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(deviceAddress);
            connState = true;
            mBluetoothLeService.connect(deviceAddress);
        }
		super.onActivityResult(requestCode, resultCode, data);
	}
}
